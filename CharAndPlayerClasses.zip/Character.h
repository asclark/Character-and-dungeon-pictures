//
//  Character.h
//  Character
//
//  Created by RX-78 01 on 3/26/13.
//  Copyright (c) 2013 lilongyue. All rights reserved.
//

#ifndef __Character__Character__
#define __Character__Character__

#include <iostream>

class Character
{
private:
    int _hitPoints, _maxHitPoints, _experience, _level, _attack, _defense, _dodge, _mana, _maxMana, _weaponDamage;
    
public:
    bool hit (int hitPoints);//setter function for changing hit points in fight function
    int defense();//getter method for getting defense used in fight function
    int attack(int defense);//returns hit points to take off of player/monster, if negative, then miss
};

#endif /* defined(__Character__Character__) */
