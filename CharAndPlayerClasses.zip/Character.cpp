//
//  Character.cpp
//  Character
//
//  Created by RX-78 01 on 3/26/13.
//  Copyright (c) 2013 lilongyue. All rights reserved.
//

#include "Character.h"

bool Character::hit (int hitPoints)
{
    bool isDead = false;
    _hitPoints -= hitPoints;
    if(_hitPoints == 0)
    {
        isDead = true;
        return isDead;
    }
    else
    {
        return isDead;
    }
}

int Character::defense()
{
    return _defense;
}

int Character::attack(int defense)
{
    if(_attack > defense)
    {
        return hit(_weaponDamage);
    }
    else
    {
        return 0;
    }
}