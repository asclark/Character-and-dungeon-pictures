//
//  Player.h
//  Character
//
//  Created by RX-78 01 on 3/26/13.
//  Copyright (c) 2013 lilongyue. All rights reserved.
//

#ifndef __Character__Player__
#define __Character__Player__

#include <iostream>
#include "Character.h"
#include "Monster.h"

class Player: public Character
{
private:
    int _mana, _potions, _coins;
    
public:
    Player();
    bool randomEncounter();
    void levelingSystem();
    void enemyDrop (Monster monster);
    void treasureChest();
    void movementDescription();
    void magicAttack();
    void addPotion(int numPotions);
    
};

#endif /* defined(__Character__Player__) */
